PROJETO: Semáforo Inteligente para Pedestres
---------------------------------------------

Descrição:
Este projeto foi desenvolvido como parte da disciplina de Sistemas Digitais.
Simula um semáforo inteligente com controle de pedestres usando Arduino.

Arquivos:

- index.html ........ Página inicial do site
- projeto.html ...... Explicação do projeto e seu objetivo
- montagem.html ..... Passo a passo da montagem do circuito
- codigo.html ....... Código do Arduino e botão de download
- extras.html ....... Informações complementares
- autores.html ...... Lista dos participantes

- style.css .......... Arquivo de estilo do site
- sketch_sinaliza.ino Código do Arduino (abrir na IDE do Arduino)
- pasta imagens/ ..... Contém todas as imagens usadas no site e no passo a passo

Requisitos:
- Navegador Web (para abrir os arquivos .html)
- Arduino IDE instalado para abrir e carregar o código .ino

Instruções:
1. Para visualizar o site, abra o arquivo `index.html` no navegador.
2. Para subir o código no Arduino, abra o arquivo `sketch_sinaliza.ino` na IDE do Arduino.
3. Para montar o circuito, siga o guia visual na página `montagem.html`.

Equipe:
- Augusto Venâncio
- Júlia Moscariello
- Júlio Sales
- Nícolas Vitor
- Rafaela Barreto

---------------------------------------------
